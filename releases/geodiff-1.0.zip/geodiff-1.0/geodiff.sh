java -jar GeoDiff.jar -ini test/dataset_initial.gpkg -fin test/dataset_final.gpkg -o out/
