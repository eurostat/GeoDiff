java -jar GeoDiff.jar -m diff -v1 test/dataset_initial.gpkg -v2 test/dataset_final.gpkg
java -jar GeoDiff.jar -m up -d test/dataset_initial.gpkg -c test/geodiff.gpkg